# SupportNow - Client JavaFX

## Architecture

Toute la communication fonctionnelle avec le serveur (login, tickets, chat)
passe par **WebSocket/STOMP** vers le serveur Spring Boot de ta binôme.
Le SOAP+UDDI imposé par le prof est géré séparément côté serveur, sans lien
avec ce flux applicatif.

## Structure du projet

```
src/main/java/iut/helpdesk/client
├── model/          Ticket, User, Message (alignés sur le schéma de la BDD)
├── service/
│   ├── HelpdeskService       contrat des opérations serveur
│   ├── MockHelpdeskService    implémentation temporaire en mémoire
│   └── Session                utilisateur connecté + config serveur
├── controller/     LoginController, DashboardController
└── App.java        point d'entrée + navigation entre écrans

src/main/resources
├── view/           fichiers .fxml (un par écran)
└── css/            styles.css
```

## Schéma de données (fourni par le serveur)

- **users** : id, name, email, password, role, created_at, updated_at
- **categories** : id, name, description
- **tickets** : id, client_id, category_id, subject, description, status
  (NEW / IN_PROGRESS / RESOLVED / CLOSED probablement — à confirmer avec
  ta binôme), created_at, update_at, closed_at
- **messages** : id, ticket_id, sender_id, content, sent_at

Les modèles Java (`Ticket`, `User`, `Message`) sont déjà alignés sur ces
noms de champs pour limiter le travail de mapping une fois connecté au
vrai serveur.

## Lancer le projet

### Avec Maven (en ligne de commande, si vous avez le JDK 17+ et Maven installés)
```
mvn clean javafx:run
```

### Avec IntelliJ IDEA
1. `File > Open`, sélectionner ce dossier (celui qui contient `pom.xml`).
2. Attendre le téléchargement des dépendances (panneau Maven à droite).
3. Panneau Maven > helpdesk-client > Plugins > javafx > double-clic sur `javafx:run`.

### Avec Eclipse
1. `File > Import > Existing Maven Project`, sélectionner ce dossier.
2. Clic droit sur `App.java` > `Run As > Java Application`.
3. Si Eclipse ne trouve pas les modules JavaFX, installer le plugin **e(fx)clipse**.

## Où en est le développement

- [x] Structure du projet
- [x] Écran de login (fonctionnel avec un service mocké)
- [x] Navigation login -> dashboard
- [x] Dashboard (compteurs en cours/résolues/total + tableau des tickets)
- [x] Écran "nouvelle demande" (sujet, catégorie, message, envoyer)
- [x] Chat temps réel (mocké pour l'instant, voir MockChatService)
- [ ] Remplacer MockHelpdeskService et MockChatService par les vraies
      implémentations STOMP

## Brancher le vrai serveur (quand les infos WebSocket/STOMP sont prêtes)

Demander à ta binôme :
- l'URL de connexion WebSocket (ex: `ws://localhost:8080/ws`)
- les destinations STOMP exactes pour chaque opération
  (ex: `/app/login`, `/app/ticket.create`, `/topic/tickets`,
  `/app/chat.send`, `/topic/ticket/{id}/messages`...)
- le format exact des messages échangés (JSON attendu/envoyé)

Ensuite créer une classe `StompHelpdeskService implements HelpdeskService`
qui utilise un client STOMP (par ex. `WebSocketStompClient` fourni par
Spring, utilisable même dans une appli Java classique via les dépendances
`spring-websocket` + `spring-messaging`), et remplacer dans les
controllers :
```java
private final HelpdeskService helpdeskService = new StompHelpdeskService();
```
au lieu de `new MockHelpdeskService()`.

## Notes importantes

- **Threading JavaFX** : toute mise à jour de l'UI depuis un thread réseau
  (réponse WebSocket/STOMP) doit passer par `Platform.runLater(() -> { ... })`,
  sinon l'appli plante ou se comporte bizarrement.
- **Config serveur** : l'URL WebSocket est centralisée dans `Session.java`
  (`WEBSOCKET_ENDPOINT`) — à mettre à jour dès que ta binôme te la donne.
- **Statuts des tickets** : le dashboard suppose les valeurs NEW,
  IN_PROGRESS, RESOLVED, CLOSED (déduit du défaut `'NEW'` dans la base).
  À confirmer avec ta binôme pour être sûr que ça correspond exactement.
