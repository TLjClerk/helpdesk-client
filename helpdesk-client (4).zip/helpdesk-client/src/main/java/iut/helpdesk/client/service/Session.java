package iut.helpdesk.client.service;

import iut.helpdesk.client.model.User;

/**
 * Contient les infos de session courante (utilisateur connecté),
 * accessible depuis n'importe quel controller.
 * A adapter/remplacer si vous préférez l'injection de dépendances plus tard.
 */
public final class Session {

    private static Session instance;

    private User currentUser;

    // Instance UNIQUE et PARTAGÉE entre tous les controllers, pour que les
    // tickets créés sur un écran soient bien visibles sur les autres
    // (ex: dashboard). A remplacer par une vraie implémentation STOMP le
    // jour venu, sans changer les controllers qui l'utilisent.
    private HelpdeskService helpdeskService = new MockHelpdeskService();

    // Idem pour le chat : une seule instance partagée pour tous les écrans.
    private ChatService chatService = new MockChatService();

    // A adapter dès que ta binôme te donne l'URL WebSocket réelle du serveur
    // (toute la communication fonctionnelle passe par WebSocket/STOMP)
    public static final String WEBSOCKET_ENDPOINT = "ws://localhost:8080/ws";

    private Session() {
    }

    public static Session getInstance() {
        if (instance == null) {
            instance = new Session();
        }
        return instance;
    }

    public HelpdeskService getHelpdeskService() {
        return helpdeskService;
    }

    public void setHelpdeskService(HelpdeskService helpdeskService) {
        this.helpdeskService = helpdeskService;
    }

    public ChatService getChatService() {
        return chatService;
    }

    public void setChatService(ChatService chatService) {
        this.chatService = chatService;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public void logout() {
        this.currentUser = null;
    }
}
