package iut.helpdesk.client.service;

import iut.helpdesk.client.model.Message;

/**
 * Contrat du service de chat temps réel.
 *
 * IMPORTANT : dès que ta binôme te donne les destinations STOMP exactes
 * (ex: s'abonner à /topic/ticket/{id}/messages et envoyer sur
 * /app/chat.send), crée une implémentation StompChatService qui utilise
 * un client STOMP (voir HelpdeskService pour plus de détails). Le
 * MessageListener sera alors notifié depuis un thread réseau, donc son
 * implémentation devra passer par Platform.runLater pour toucher l'UI -
 * exactement comme MockChatService le fait déjà pour t'y habituer.
 */
public interface ChatService {

    /**
     * Se connecte au chat d'un ticket donné et commence à écouter les
     * nouveaux messages (y compris ses propres messages, renvoyés en écho,
     * pour rester cohérent avec un vrai serveur qui diffuse à tous les
     * abonnés du topic).
     */
    void connect(Long ticketId, MessageListener listener);

    /**
     * Envoie un message dans le chat du ticket actuellement connecté.
     */
    void sendMessage(Long ticketId, String content);

    /**
     * Se déconnecte du chat (à appeler en quittant l'écran).
     */
    void disconnect();

    interface MessageListener {
        void onMessageReceived(Message message);
    }
}
