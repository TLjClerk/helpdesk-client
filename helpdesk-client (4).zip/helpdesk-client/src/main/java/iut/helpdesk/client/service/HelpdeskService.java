package iut.helpdesk.client.service;

import iut.helpdesk.client.model.Ticket;
import iut.helpdesk.client.model.User;

import java.util.List;

/**
 * Contrat des opérations avec le serveur.
 *
 * Toute la communication fonctionnelle (login, tickets, chat) passe par
 * WebSocket/STOMP vers le serveur Spring Boot. Le SOAP+UDDI imposé par le
 * prof est géré séparément (exigence isolée, sans lien avec ce flux).
 *
 * IMPORTANT : dès que ta binôme te donne les destinations STOMP exactes
 * (ex: /app/login, /topic/tickets, /app/chat.send, /topic/ticket/{id}...),
 * crée une implémentation StompHelpdeskService qui utilise un client STOMP
 * (par ex. WebSocketStompClient de Spring, disponible même dans une appli
 * Java classique via les dépendances spring-websocket + spring-messaging).
 * Tant que ce n'est pas prêt, MockHelpdeskService te permet d'avancer sur
 * les écrans sans être bloqué.
 */
public interface HelpdeskService {

    /**
     * @return l'utilisateur connecté si les identifiants sont valides, sinon null
     */
    User login(String email, String motDePasse);

    /**
     * Crée une nouvelle demande (ticket) pour l'utilisateur courant.
     */
    Ticket creerTicket(String subject, String category, String description);

    /**
     * @return la liste des tickets de l'utilisateur courant
     */
    List<Ticket> listerTickets();
}
