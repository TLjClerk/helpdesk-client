package iut.helpdesk.client.service;

import iut.helpdesk.client.model.Ticket;
import iut.helpdesk.client.model.User;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Implémentation temporaire en mémoire, le temps que le vrai serveur
 * (WebSocket/STOMP côté ta binôme) soit disponible.
 *
 * Accepte n'importe quel email/mot de passe non vides pour se connecter.
 * A remplacer par une vraie implémentation StompHelpdeskService quand les
 * destinations STOMP seront communiquées (voir HelpdeskService).
 */
public class MockHelpdeskService implements HelpdeskService {

    private final List<Ticket> tickets = new ArrayList<>();
    private final AtomicLong idGenerator = new AtomicLong(1);
    private final AtomicLong userIdGenerator = new AtomicLong(1);

    public MockHelpdeskService() {
        // Données d'exemple pour pouvoir tester le dashboard visuellement.
        // A retirer une fois connecté au vrai serveur.
        Ticket t1 = new Ticket("Problème de connexion", "Connexion", "Je n'arrive pas à me connecter depuis ce matin.");
        t1.setId(idGenerator.getAndIncrement());
        t1.setCreatedAt("13/09/2026");

        Ticket t2 = new Ticket("Écran bleu au démarrage", "Technique", "L'ordinateur affiche un écran bleu.");
        t2.setId(idGenerator.getAndIncrement());
        t2.setStatus(Ticket.Status.RESOLVED);
        t2.setCreatedAt("10/09/2026");

        Ticket t3 = new Ticket("Mot de passe oublié", "Compte", "Impossible de réinitialiser mon mot de passe.");
        t3.setId(idGenerator.getAndIncrement());
        t3.setStatus(Ticket.Status.IN_PROGRESS);
        t3.setCreatedAt("14/09/2026");

        tickets.add(t1);
        tickets.add(t2);
        tickets.add(t3);
    }

    @Override
    public User login(String email, String motDePasse) {
        if (email == null || email.isBlank() || motDePasse == null || motDePasse.isBlank()) {
            return null;
        }
        // Simule une authentification réussie
        return new User(userIdGenerator.getAndIncrement(), email.split("@")[0], email);
    }

    @Override
    public Ticket creerTicket(String subject, String category, String description) {
        Ticket ticket = new Ticket(subject, category, description);
        ticket.setId(idGenerator.getAndIncrement());
        ticket.setCreatedAt(java.time.LocalDateTime.now().toString());
        tickets.add(ticket);
        return ticket;
    }

    @Override
    public List<Ticket> listerTickets() {
        return tickets;
    }
}
