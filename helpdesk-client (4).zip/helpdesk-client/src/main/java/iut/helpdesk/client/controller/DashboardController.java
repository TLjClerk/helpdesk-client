package iut.helpdesk.client.controller;

import iut.helpdesk.client.App;
import iut.helpdesk.client.model.Ticket;
import iut.helpdesk.client.service.HelpdeskService;
import iut.helpdesk.client.service.Session;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class DashboardController {

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label enCoursLabel;

    @FXML
    private Label resoluesLabel;

    @FXML
    private Label totalLabel;

    @FXML
    private TableView<Ticket> ticketsTable;

    @FXML
    private TableColumn<Ticket, String> sujetColumn;

    @FXML
    private TableColumn<Ticket, String> categorieColumn;

    @FXML
    private TableColumn<Ticket, Ticket.Status> statutColumn;

    @FXML
    private TableColumn<Ticket, String> dateColumn;

    private final HelpdeskService helpdeskService = Session.getInstance().getHelpdeskService();

    @FXML
    public void initialize() {
        var user = Session.getInstance().getCurrentUser();
        if (user != null) {
            welcomeLabel.setText("Bienvenue, " + user.getName());
        }

        sujetColumn.setCellValueFactory(new PropertyValueFactory<>("subject"));
        categorieColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        statutColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("createdAt"));

        // Double-clic sur une ligne = ouvrir directement le chat de ce ticket
        ticketsTable.setRowFactory(table -> {
            javafx.scene.control.TableRow<Ticket> row = new javafx.scene.control.TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    App.showChat(row.getItem());
                }
            });
            return row;
        });

        chargerTickets();
    }

    private void chargerTickets() {
        // Appel réseau : à faire en tâche de fond (Task/Thread + Platform.runLater)
        // dès que ce sera un vrai appel STOMP, pour ne pas geler l'UI.
        var tickets = helpdeskService.listerTickets();

        ObservableList<Ticket> data = FXCollections.observableArrayList(tickets);
        ticketsTable.setItems(data);

        long enCours = tickets.stream()
                .filter(t -> t.getStatus() == Ticket.Status.NEW || t.getStatus() == Ticket.Status.IN_PROGRESS)
                .count();
        long resolues = tickets.stream()
                .filter(t -> t.getStatus() == Ticket.Status.RESOLVED || t.getStatus() == Ticket.Status.CLOSED)
                .count();

        enCoursLabel.setText(String.valueOf(enCours));
        resoluesLabel.setText(String.valueOf(resolues));
        totalLabel.setText(String.valueOf(tickets.size()));
    }

    @FXML
    private void handleNouvelleDemande() {
        App.showNouvelleDemande();
    }

    @FXML
    private void handleOuvrirChat() {
        Ticket selected = ticketsTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Sélection requise");
            alert.setHeaderText(null);
            alert.setContentText("Sélectionnez d'abord une demande dans le tableau (ou double-cliquez dessus).");
            alert.showAndWait();
            return;
        }
        App.showChat(selected);
    }
}
