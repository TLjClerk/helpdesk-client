package iut.helpdesk.client.service;

import iut.helpdesk.client.model.Message;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Implémentation temporaire en mémoire du chat, le temps que le vrai
 * serveur WebSocket/STOMP soit disponible.
 *
 * Simule un serveur réel : la réponse de l'admin arrive après un court
 * délai, sur un thread séparé (ScheduledExecutorService) - exactement le
 * genre de situation qui obligera le controller à passer par
 * Platform.runLater pour mettre à jour l'UI sans planter.
 */
public class MockChatService implements ChatService {

    public static final long ADMIN_ID = -1L;

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final Map<Long, List<Message>> historyByTicket = new HashMap<>();
    private final AtomicLong messageIdGenerator = new AtomicLong(1);
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "mock-chat-scheduler");
        t.setDaemon(true);
        return t;
    });

    private MessageListener listener;

    @Override
    public void connect(Long ticketId, MessageListener listener) {
        this.listener = listener;
        // Rejoue l'historique déjà présent pour ce ticket (comme le ferait
        // un vrai serveur qui renvoie les messages passés à la connexion).
        historyByTicket.computeIfAbsent(ticketId, k -> new ArrayList<>())
                .forEach(listener::onMessageReceived);
    }

    @Override
    public void sendMessage(Long ticketId, String content) {
        Long senderId = Session.getInstance().getCurrentUser() != null
                ? Session.getInstance().getCurrentUser().getId() : 0L;

        Message message = buildMessage(ticketId, senderId, content);
        historyByTicket.computeIfAbsent(ticketId, k -> new ArrayList<>()).add(message);
        if (listener != null) {
            listener.onMessageReceived(message);
        }

        // Simule la réponse asynchrone d'un agent, comme le ferait un vrai
        // serveur WebSocket/STOMP (sur un thread différent de celui de l'UI).
        scheduler.schedule(() -> {
            Message reply = buildMessage(ticketId, ADMIN_ID, texteReponseAleatoire());
            historyByTicket.get(ticketId).add(reply);
            if (listener != null) {
                listener.onMessageReceived(reply);
            }
        }, 1500, TimeUnit.MILLISECONDS);
    }

    @Override
    public void disconnect() {
        this.listener = null;
    }

    private Message buildMessage(Long ticketId, Long senderId, String content) {
        Message message = new Message(ticketId, senderId, content);
        message.setId(messageIdGenerator.getAndIncrement());
        message.setSentAt(LocalDateTime.now().format(FORMAT));
        return message;
    }

    private String texteReponseAleatoire() {
        String[] reponses = {
                "Merci pour votre message, un agent va vous répondre.",
                "Nous avons bien reçu votre demande, un instant.",
                "Je regarde ça de suite."
        };
        return reponses[new Random().nextInt(reponses.length)];
    }
}
