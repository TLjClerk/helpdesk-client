package iut.helpdesk.client.controller;

import iut.helpdesk.client.App;
import iut.helpdesk.client.service.HelpdeskService;
import iut.helpdesk.client.service.Session;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class NouvelleDemandeController {

    @FXML
    private TextField sujetField;

    @FXML
    private ComboBox<String> categorieCombo;

    @FXML
    private TextArea messageArea;

    @FXML
    private Label errorLabel;

    private final HelpdeskService helpdeskService = Session.getInstance().getHelpdeskService();

    @FXML
    public void initialize() {
        // Catégories alignées sur celles vues côté admin (table "categories").
        // NB: la liste vue démarre à #2 (Connexion) - vérifier avec ta binôme
        // s'il existe une catégorie #1 qui manquerait ici.
        categorieCombo.setItems(FXCollections.observableArrayList(
                "Connexion", "Compte", "Application", "Paiement",
                "Technique", "Demande d'information", "Autre"
        ));
    }

    @FXML
    private void handleEnvoyer() {
        errorLabel.setText("");

        String sujet = sujetField.getText();
        String categorie = categorieCombo.getValue();
        String message = messageArea.getText();

        if (sujet == null || sujet.isBlank()) {
            errorLabel.setText("Merci de renseigner un sujet.");
            return;
        }
        if (categorie == null) {
            errorLabel.setText("Merci de choisir une catégorie.");
            return;
        }
        if (message == null || message.isBlank()) {
            errorLabel.setText("Merci de décrire votre problème.");
            return;
        }

        // Appel réseau : à faire en tâche de fond dès que ce sera un vrai
        // appel STOMP, pour ne pas geler l'UI.
        helpdeskService.creerTicket(sujet, categorie, message);

        App.showDashboard();
    }

    @FXML
    private void handleAnnuler() {
        App.showDashboard();
    }
}
