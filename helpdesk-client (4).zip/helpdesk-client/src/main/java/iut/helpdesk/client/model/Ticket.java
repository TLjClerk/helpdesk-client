package iut.helpdesk.client.model;

/**
 * Représente une demande (ticket) créée par le client.
 * Champs alignés sur le schéma de la base fournie par le serveur
 * (table "tickets" : subject, description, status, category, created_at).
 */
public class Ticket {

    public enum Status {
        NEW("Nouveau"),
        IN_PROGRESS("En cours"),
        RESOLVED("Résolu"),
        CLOSED("Clôturé");

        private final String libelle;

        Status(String libelle) {
            this.libelle = libelle;
        }

        @Override
        public String toString() {
            return libelle;
        }
    }

    private Long id;
    private String subject;
    private String description;
    private String category;
    private Status status;
    private String createdAt;

    public Ticket() {
    }

    public Ticket(String subject, String category, String description) {
        this.subject = subject;
        this.category = category;
        this.description = description;
        this.status = Status.NEW;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
