package iut.helpdesk.client.model;

/**
 * Représente un message échangé dans le chat d'un ticket.
 * Aligné sur la table "messages" de la base (ticket_id, sender_id, content, sent_at).
 * Utilisé une fois qu'on branchera le chat WebSocket/STOMP.
 */
public class Message {

    private Long id;
    private Long ticketId;
    private Long senderId;
    private String content;
    private String sentAt;

    public Message() {
    }

    public Message(Long ticketId, Long senderId, String content) {
        this.ticketId = ticketId;
        this.senderId = senderId;
        this.content = content;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTicketId() {
        return ticketId;
    }

    public void setTicketId(Long ticketId) {
        this.ticketId = ticketId;
    }

    public Long getSenderId() {
        return senderId;
    }

    public void setSenderId(Long senderId) {
        this.senderId = senderId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSentAt() {
        return sentAt;
    }

    public void setSentAt(String sentAt) {
        this.sentAt = sentAt;
    }
}
