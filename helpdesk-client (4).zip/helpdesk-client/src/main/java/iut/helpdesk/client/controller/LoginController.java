package iut.helpdesk.client.controller;

import iut.helpdesk.client.App;
import iut.helpdesk.client.model.User;
import iut.helpdesk.client.service.HelpdeskService;
import iut.helpdesk.client.service.Session;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Label errorLabel;

    private final HelpdeskService helpdeskService = Session.getInstance().getHelpdeskService();

    @FXML
    private void handleLogin() {
        errorLabel.setText("");

        String email = emailField.getText();
        String password = passwordField.getText();

        if (email == null || email.isBlank() || password == null || password.isBlank()) {
            errorLabel.setText("Merci de renseigner l'email et le mot de passe.");
            return;
        }

        loginButton.setDisable(true);

        // Appel réseau : à faire en tâche de fond dès que ce sera un vrai
        // appel STOMP (pour ne pas geler l'UI). Pour le mock, c'est instantané.
        User user = helpdeskService.login(email, password);

        loginButton.setDisable(false);

        if (user == null) {
            errorLabel.setText("Identifiants incorrects.");
            return;
        }

        Session.getInstance().setCurrentUser(user);
        App.showDashboard();
    }
}
