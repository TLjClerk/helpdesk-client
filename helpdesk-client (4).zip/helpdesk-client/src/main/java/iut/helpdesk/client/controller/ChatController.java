package iut.helpdesk.client.controller;

import iut.helpdesk.client.App;
import iut.helpdesk.client.model.Message;
import iut.helpdesk.client.model.Ticket;
import iut.helpdesk.client.service.ChatService;
import iut.helpdesk.client.service.Session;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class ChatController implements ChatService.MessageListener {

    @FXML
    private Label subjectLabel;

    @FXML
    private ListView<Message> messagesListView;

    @FXML
    private TextField messageField;

    private final ChatService chatService = Session.getInstance().getChatService();
    private final ObservableList<Message> messages = FXCollections.observableArrayList();

    private Ticket ticket;
    private Long currentUserId;

    /**
     * Appelé juste après le chargement du FXML (voir App.showChat), avant
     * l'affichage, pour indiquer sur quel ticket ouvrir le chat.
     */
    public void init(Ticket ticket) {
        this.ticket = ticket;
        this.currentUserId = Session.getInstance().getCurrentUser() != null
                ? Session.getInstance().getCurrentUser().getId() : null;

        subjectLabel.setText(ticket.getSubject());
        messagesListView.setItems(messages);
        messagesListView.setCellFactory(list -> new MessageCell());

        chatService.connect(ticket.getId(), this);
    }

    @Override
    public void onMessageReceived(Message message) {
        // Ce callback peut être appelé depuis un thread différent de celui
        // de l'UI (c'est déjà le cas avec MockChatService, et ce sera aussi
        // le cas avec un vrai client WebSocket/STOMP) : on passe donc
        // systématiquement par Platform.runLater pour toucher les composants.
        Platform.runLater(() -> {
            messages.add(message);
            messagesListView.scrollTo(messages.size() - 1);
        });
    }

    @FXML
    private void handleEnvoyer() {
        String content = messageField.getText();
        if (content == null || content.isBlank()) {
            return;
        }
        chatService.sendMessage(ticket.getId(), content);
        messageField.clear();
    }

    @FXML
    private void handleRetour() {
        chatService.disconnect();
        App.showDashboard();
    }

    /**
     * Cellule personnalisée pour afficher chaque message sous forme de
     * bulle, alignée à droite pour les messages de l'utilisateur courant,
     * à gauche pour ceux de l'agent/admin.
     */
    private class MessageCell extends ListCell<Message> {
        @Override
        protected void updateItem(Message message, boolean empty) {
            super.updateItem(message, empty);

            if (empty || message == null) {
                setGraphic(null);
                setText(null);
                return;
            }

            boolean isOwnMessage = currentUserId != null && currentUserId.equals(message.getSenderId());

            Label contentLabel = new Label(message.getContent());
            contentLabel.setWrapText(true);
            contentLabel.setMaxWidth(320);

            Label timeLabel = new Label(message.getSentAt());
            timeLabel.getStyleClass().add("chat-timestamp");

            VBox bubble = new VBox(4, contentLabel, timeLabel);
            bubble.setPadding(new Insets(8, 12, 8, 12));
            bubble.getStyleClass().add(isOwnMessage ? "chat-bubble-own" : "chat-bubble-admin");

            HBox container = new HBox(bubble);
            container.setAlignment(isOwnMessage ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
            container.setPadding(new Insets(4, 8, 4, 8));

            setGraphic(container);
            setText(null);
        }
    }
}
