package iut.helpdesk.client;

import iut.helpdesk.client.controller.ChatController;
import iut.helpdesk.client.model.Ticket;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class App extends Application {

    private static Stage primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        stage.setTitle("SupportNow");
        showLogin();
        stage.show();
    }

    public static void showLogin() {
        loadScene("/view/login.fxml", 400, 420);
    }

    public static void showDashboard() {
        loadScene("/view/dashboard.fxml", 800, 600);
    }

    public static void showNouvelleDemande() {
        loadScene("/view/nouvelle_demande.fxml", 560, 560);
    }

    public static void showChat(Ticket ticket) {
        FXMLLoader loader = loadScene("/view/chat.fxml", 600, 650);
        ChatController controller = loader.getController();
        controller.init(ticket);
    }

    private static FXMLLoader loadScene(String fxmlPath, double width, double height) {
        try {
            FXMLLoader loader = new FXMLLoader(App.class.getResource(fxmlPath));
            Parent root = loader.load();
            Scene scene = new Scene(root, width, height);
            scene.getStylesheets().add(App.class.getResource("/css/styles.css").toExternalForm());
            primaryStage.setScene(scene);
            return loader;
        } catch (IOException e) {
            throw new RuntimeException("Impossible de charger " + fxmlPath, e);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
